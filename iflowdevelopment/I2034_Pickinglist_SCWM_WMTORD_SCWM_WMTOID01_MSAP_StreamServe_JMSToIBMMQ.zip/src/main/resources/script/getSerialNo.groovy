import com.sap.it.api.mapping.*
import groovy.util.XmlParser
// UDF: Extracts Serial Numbers from IDoc XML by Warehouse Task Number
def void getSerialNo(String[] warehouseTaskNo, Output output, MappingContext context) {
// Read IDoc XML from exchange property set by Content Modifier
    def rawXml = context.getProperty("IDOC_XML")
// Output blank for each input if property is missing
    if (!rawXml) {
        warehouseTaskNo.each { output.addValue("") }
        return
    }
// Trim whitespace and strip BOM character
    def cleanXml = rawXml.toString().trim().replaceAll("^\uFEFF", "")
// Abort if string is not valid XML
    if (!cleanXml.startsWith("<")) {
        warehouseTaskNo.each { output.addValue("") }
        return
    }
// Parse XML without namespace awareness to handle SAP prefixes
    def parsed = new XmlParser(false, false).parseText(cleanXml)
// Find Message1 node inside multimap structure
    def idocNode = parsed.depthFirst().find { node ->
        node.name().toString().contains("Message1")
    }
// Use Message1 content or fall back to root node
    def idoc = idocNode ? idocNode : parsed
warehouseTaskNo.each { whTaskNo ->
// Skip null or empty task numbers
        if (!whTaskNo) {
            output.addValue("")
            return
        }
// Strip leading zeros for comparison (e.g. "000100000806" → "100000806")
        def taskNo = whTaskNo.trim().replaceFirst("^0+", "")
// Find E1LTORI segment where TANUM[coming from IDOC] matches the task number[whTaskNo coming from custom ODATA]
        def matchingItem = idoc.depthFirst().find { node ->
            node.name().toString().contains("E1LTORI") &&
            node.TANUM?.text()?.trim()?.replaceFirst("^0+", "") == taskNo
        }
if (matchingItem) {
            // Get all E1LCRSE child segments (serial number segments)
            def serialNodes = matchingItem.children().findAll { child ->
                child.name().toString().contains("E1LCRSE")
            }
// Collect non-empty SERID values from each serial node
            def serialNumbers = serialNodes.collect { it.SERID?.text()?.trim() }.findAll { it }
if (serialNumbers) {
                // Output each serial number separately
                serialNumbers.each { output.addValue(it) }
            } else {
                // No serial numbers found — output blank
                output.addValue("")
            }
        } else {
            output.addValue("")
        }
    }
}