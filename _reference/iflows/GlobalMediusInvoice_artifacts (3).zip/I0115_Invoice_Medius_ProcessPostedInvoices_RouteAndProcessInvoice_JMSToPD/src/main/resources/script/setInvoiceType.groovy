import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def mediusDocumentType = message.getProperty("MediusDocumentType")?.toString()
    def erpId = message.getProperty("ERPId")?.toString()
    def CH_OTM_Shipment_Mill = message.getProperty("CH_OTM_Shipment_Mill")?.toString()
    def OTM_Lulea_Mill = message.getProperty("OTM_Lulea_Mill")?.toString()

    if ("EXPENSE".equalsIgnoreCase(mediusDocumentType)) {
        message.setProperty("InvoiceType", "Expense")
    }else if("OTM".equalsIgnoreCase(erpId)){
        if(CH_OTM_Shipment_Mill.equals(OTM_Lulea_Mill)){
            message.setProperty("InvoiceType", "OrderBased")
        }else{
            message.setProperty("InvoiceType", "Expense")
        }
    }
    else {
        message.setProperty("InvoiceType", "OrderBased")
    }

    return message
}