<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns2="urn:sap-com:document:sap:rfc:functions">
	<xsl:output method="xml" indent="yes" encoding="UTF-8"/>
	<!-- Identity transform: Copy all other nodes and attributes as-is -->
	<xsl:template match="@*|node()">
		<xsl:copy>
			<xsl:apply-templates select="@*|node()"/>
		</xsl:copy>
	</xsl:template>
	<!-- Target TRANSPORTATION_ORDERS to group items by OTM_SHIPMENT_ID -->
	<xsl:template match="TRANSPORTATION_ORDERS">
		<xsl:copy>
			<xsl:for-each-group select="item" group-by="OTM_SHIPMENT_ID">
				<item>
					<OTM_SHIPMENT_ID>
						<xsl:value-of select="current-grouping-key()"/>
					</OTM_SHIPMENT_ID>
					<TRANSPORTATION_CHARGE>
						<CHARGE_ITEM>
							<CALCULATION_DATE>
								<xsl:value-of select="current-group()[1]/TRANSPORTATION_CHARGE/CHARGE_ITEM/CALCULATION_DATE"/>
							</CALCULATION_DATE>
							<CHARGE_ELEMENTS>
								<!-- Loop through all charge elements across the grouped items and renumber ordinal values -->
								<xsl:for-each select="current-group()/TRANSPORTATION_CHARGE/CHARGE_ITEM/CHARGE_ELEMENTS/item">
									<item>
										<ORDINAL_NUMBER_VALUE>
											<xsl:value-of select="position()"/>
										</ORDINAL_NUMBER_VALUE>
										<TYPE_CODE>
											<xsl:value-of select="TYPE_CODE"/>
										</TYPE_CODE>
										<PRICE_COMPONENT>
											<DECIMAL_VALUE>
												<xsl:value-of select="PRICE_COMPONENT/DECIMAL_VALUE"/>
											</DECIMAL_VALUE>
											<CURRENCY_CODE>
												<xsl:value-of select="PRICE_COMPONENT/CURRENCY_CODE"/>
											</CURRENCY_CODE>
										</PRICE_COMPONENT>
									</item>
								</xsl:for-each>
							</CHARGE_ELEMENTS>
						</CHARGE_ITEM>
					</TRANSPORTATION_CHARGE>
				</item>
			</xsl:for-each-group>
		</xsl:copy>
	</xsl:template>
</xsl:stylesheet>