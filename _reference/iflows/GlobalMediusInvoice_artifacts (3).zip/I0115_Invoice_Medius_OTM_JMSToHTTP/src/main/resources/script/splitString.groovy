import com.sap.it.api.mapping.*

/*Add MappingContext parameter to read or set headers and properties
def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

Add Output parameter to assign the output value.
def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}*/

def String splitString(String inputString, int index,String separator){
    def parts = inputString.split(separator)
    return (index > 0 && index <= parts.size()) ? parts[index - 1] : null
}


def void getConnectedValue(String[] sourceValue, String[] relatedValue, String[] requiredValue, Output output, MappingContext context) {
    for (int i = 0; i < sourceValue.length; i++) {
        for (int j = 0; j < relatedValue.length; j++) {
            if (relatedValue[j].equals(sourceValue[i])) {
                //output.addValue(requiredValue[j])
                output.addValue((requiredValue?.size() > j) ? requiredValue[j] : "")
                break
            }
        }
    }
}

// Concatenate PurchaseOrderLineNumber and Amount from Invoice, e.g. 1/234.50, 2/-15.0
// Conactenated value is parsed in getAmount
def void getConnectedValueAmount(String[] sourceValue, String[] relatedValue, String[] requiredValue, String[] amount, Output output, MappingContext context) {
    String itemAmount = ""
    for (int i = 0; i < sourceValue.length; i++) {
        for (int j = 0; j < relatedValue.length; j++) {
            if (relatedValue[j].equals(sourceValue[i])) {
                itemAmount = requiredValue[j] + "/" + amount[i]
                output.addValue((requiredValue?.size() > j) ? itemAmount : "")
                break
            }
        }
    }
}


// Get Amount by parsing concatenated value from getConnectedValueAmount, e.g. 1/234.50, 2/-15.0
def void getAmount(String[] poLineNumber, String[] lineAmount, Output output, MappingContext context) {
    
    String lineNumber = ""
    String amount = ""

    for (int i = 0; i < poLineNumber.length; i++) {
        for (int j = 0; j < lineAmount.length; j++) {
            lineNumber = lineAmount[j].split("/")[0]
            if (lineNumber.equals(poLineNumber[i])) {
                amount = lineAmount[j].split("/")[1]
                output.addValue(amount)
            }
        }
    }
}


// Get Item number 
def void getItemNumber(String[] poLineNumber, String[] itemNumber, String[] invPOItemNumber, Output output, MappingContext context) {

    for (int i = 0; i < poLineNumber.length; i++) {
        for (int j = 0; j < invPOItemNumber.length; j++) {
            if (invPOItemNumber[j].equals(poLineNumber[i])) {
                output.addValue(itemNumber[i])
            }
        }
    }
}


def String cropString(String str, int maxLength, MappingContext context) {
    if(str.length() > maxLength){
        str = str.substring(0, maxLength);
    }
    return str
}


// Add ShipmentCost for NON Collective invoices
// Create from exceptionTypeConnection for Regular invoices
def void createShipmentCostForException(String[] purchaseOrderNumber, String[] lineNumber, Output output, MappingContext context) {
    

    // Clean up: trim and remove empty/null entries
    def cleanList = purchaseOrderNumber.findAll { it?.trim() }.collect { it.trim() }

    // Create a set of unique values
    def uniquePOs = cleanList.toSet()

    // If more than one unique PO number → it's a collective invoice
    if (uniquePOs.size() == 1) {
        for (int i = 0; i < lineNumber.length; i++) {
            output.addValue([i])
        }
    }
}

// Match deviations to purchase order number -> Create ShipmentCost
// Script is used to put deviations on correct purchase order
def void createShipmentCost(String[] poNumber, String[] poNumberDeviation, Output output, MappingContext context) {
    for (int i = 0; i < poNumber.length; i++) {
        for (int j = 0; j < poNumberDeviation.length; j++) {
            if (poNumberDeviation[j].equals(poNumber[i])) {
                output.addValue(poNumberDeviation[j])
            }
        }
        output.addContextChange();
    }
}


// Get Deviation Amount
// If poConnectionNo = "0" it means that it is an Exception amount and should be excluded
// If deviationType = "UnitPriceDeviation" the amount should be picked from the CodingLine (in this case deviationAmount contains unit price instead of amount)
def void getDeviationAmount(String[] poConnectionNo, String[] deviationType, String[] deviationAmount, String[] codingLineNoDeviation, String[] codingLineNo, String[] codingLineAmount, Output output, MappingContext context) {
    
    String codingLineNoDev = ""
    String amount = ""

    for (int i = 0; i < poConnectionNo.length; i++) {
        if (!poConnectionNo[i].equals("0")) {
            amount = deviationAmount[i]
            if (deviationType[i].equals("UnitPriceDeviation")) {
                codingLineNoDev = codingLineNoDeviation[i]
                for (int j = 0; j < codingLineNo.length; j++) {
                    if (codingLineNo[j].equals(codingLineNoDev)) {
                        amount = codingLineAmount[j]
                        break
                    }
                }
            }
            output.addValue(amount)
        }
    }
}



// Add value from "source structure" if relatedValue is found
def void filterInclude(String[] sourceValue, String[] relatedValue, String[] requiredValue, Output output, MappingContext context) {

    // Build related id set (trimmed)
    def relatedSet = relatedValue ? relatedValue.collect { it?.trim() }.toSet() : [] as Set

    // Loop over sourceValue, if a relatedValue is found -> add requiredValue
    for (int i = 0; i < sourceValue.length; i++) {
        def item = sourceValue[i]?.trim()

        if (relatedSet.contains(item)) {
            output.addValue(requiredValue[i])
        }
    }
}

// Add value from "source structure" if relatedValue is NOT found
def void filterExclude(String[] sourceValue, String[] relatedValue, String[] requiredValue, Output output, MappingContext context) {

    // Build related id set (trimmed)
    def relatedSet = relatedValue ? relatedValue.collect { it?.trim() }.toSet() : [] as Set

    // Loop over sourceValue, if a relatedValue is NOT found -> add requiredValue
    for (int i = 0; i < sourceValue.length; i++) {
        def item = sourceValue[i]?.trim()

        if (!relatedSet.contains(item)) {
            output.addValue(requiredValue[i])
        }
    }
}








