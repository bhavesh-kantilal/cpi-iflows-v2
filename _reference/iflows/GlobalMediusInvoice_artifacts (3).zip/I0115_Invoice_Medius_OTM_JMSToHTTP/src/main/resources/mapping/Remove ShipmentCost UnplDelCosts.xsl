<?xml version="1.0" encoding="UTF-8"?>
<!-- Remove ShipmentCost element for rounding differences, i.e. where GeneralLedgerGid = 'UnplDelCosts' -->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns1="http://xmlns.oracle.com/apps/otm/transmission/v6.4" version="1.0" exclude-result-prefixes="ns1">
	<!-- Identity transform (copies everything by default) -->
	<xsl:template match="@*|node()">
		<xsl:copy>
			<xsl:apply-templates select="@*|node()"/>
		</xsl:copy>
	</xsl:template>
	<!-- Suppress ShipmentCost where GeneralLedgerGid/Gid/Xid = 'UnpDelCosts' -->
	<xsl:template match="ns1:ShipmentCost[ns1:GeneralLedgerGid/ns1:Gid/ns1:Xid='UnplDelCosts']"/>
</xsl:stylesheet>