import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def arr_receiversQueueList = []
    def arr_receiversIFlowList = []
    def counter = 0

    // Medius -> I0702 common dispatcher queue (only receiver; ASAP decommissioned)
    arr_receiversQueueList.add("I0702_Medius")
    arr_receiversIFlowList.add("I0541_InternalOrder_FSAP_Medius_PDToREST")
    counter++

    message.setProperty("arr_receiversQueueList", arr_receiversQueueList)
    message.setProperty("arr_receiversIFlowList", arr_receiversIFlowList)
    message.setProperty("arr_receiversLastIndex", counter - 1)
    return message
}
