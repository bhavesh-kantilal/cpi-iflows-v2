\
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def arr_receiversQueueList = []
    def arr_receiversIFlowList = []
    def counter = 0

    // Medius -> I0710 common dispatcher queue
    arr_receiversQueueList.add("I0710_Medius")
    arr_receiversIFlowList.add("I0544_BusinessPartner_FSAP_Medius_PDToREST")
    counter++

    // StreamServe DDS -> I0711 common dispatcher queue
    arr_receiversQueueList.add("I0711_StreamServe")
    arr_receiversIFlowList.add("I0544_BusinessPartner_FSAP_StreamServeDDS_PDToJDBC")
    counter++

    // MSAP -> dedicated queue (dummy: iFlow name = queue name)
    arr_receiversQueueList.add("I0544_MSAP")
    arr_receiversIFlowList.add("I0544_MSAP")
    counter++

    message.setProperty("arr_receiversQueueList", arr_receiversQueueList)
    message.setProperty("arr_receiversIFlowList", arr_receiversIFlowList)
    message.setProperty("arr_receiversLastIndex", counter - 1)
    return message
}
