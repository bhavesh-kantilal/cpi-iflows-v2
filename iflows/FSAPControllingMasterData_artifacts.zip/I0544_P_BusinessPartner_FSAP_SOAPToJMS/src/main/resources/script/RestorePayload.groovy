import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def queueList = message.getProperty("QUEUE_LIST") as List
    def idx = (message.getProperty("QUEUE_INDEX") ?: 0) as Integer

    // 1) Restore original payload BEFORE sending
    message.setBody(message.getProperty("ORIGINAL_BODY"))

    // 2) Set ONE queue name per iteration
    def q = (queueList && idx < queueList.size()) ? (queueList[idx] as String).trim() : null
    if (!q) {
        throw new IllegalStateException("QueueName is empty for index=" + idx)
    }
    message.setHeader("QueueName", q)

    // 3) Increment index for next loop iteration
    message.setProperty("QUEUE_INDEX", idx + 1)

    return message
}