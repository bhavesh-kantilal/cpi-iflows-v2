import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def queueList = message.getProperty("QUEUE_LIST") as List
    def idx = (message.getProperty("QUEUE_INDEX") as Integer) ?: 0

    if (queueList == null || queueList.isEmpty()) {
        throw new IllegalStateException("QUEUE_LIST is empty - nothing to send")
    }
    if (idx < 0 || idx >= queueList.size()) {
        throw new IllegalStateException("QUEUE_INDEX out of range: " + idx + " / size=" + queueList.size())
    }

    message.setHeader("QueueName", queueList[idx].toString())
    return message
}