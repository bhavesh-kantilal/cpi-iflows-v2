import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def idx = message.getProperty("QUEUE_INDEX") as Integer
    message.setProperty("QUEUE_INDEX", idx + 1)
    return message
}