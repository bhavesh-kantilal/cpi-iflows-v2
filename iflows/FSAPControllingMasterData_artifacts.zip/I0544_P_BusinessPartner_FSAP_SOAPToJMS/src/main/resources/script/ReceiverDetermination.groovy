import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def companyCode = message.getProperty("CC_COMPANY_CODE") as String
    def ioQueuesRaw = message.getProperty("IO_QUEUES") as String  // e.g. "I0542_MOBILE,I0539_ORACLE"

    def queueList = []

    if (ioQueuesRaw) {
        queueList = ioQueuesRaw.split(',')
                .collect { it.trim() }
                .findAll { it }
    }

    message.setProperty("QUEUE_LIST", queueList)                 // List
    message.setProperty("QUEUE_LIST_SIZE", queueList.size())     // Integer
    message.setProperty("QUEUE_INDEX", 0)                        // Integer
    
    message.setProperty("ORIGINAL_BODY", message.getBody(String))

    return message
}
